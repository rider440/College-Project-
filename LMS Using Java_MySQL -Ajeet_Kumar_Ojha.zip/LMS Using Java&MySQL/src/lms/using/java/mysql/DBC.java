/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lms.using.java.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Ajeet
 */
public class DBC {
    public static Connection Connect(){
        Connection con = null;
        String s1= "jdbc:mysql://localhost:3306/LMS";
        String s2= "root";
        String s3= "Ajeet2004@";
        
        try {
            con= DriverManager.getConnection(s1,s2,s3);
        } catch (SQLException ex) {
            Logger.getLogger(DBC.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
}
